# What's next?

SyntaxHighlighter is one of the most popular highlighters on the web today. I'm surprised 
and excited to see it on nearly every other blog out there. It's pretty awesome!

Unfortunately I haven't had much time to up keep the project and I'm looking for help! Over
the last months I've been thinking about the next iteration and have a bunch of interesting
ideas on where to take this project... but I'm in desperate need of help on this. If you are
interested in joining, drop me a note! Lets write the next version together!
