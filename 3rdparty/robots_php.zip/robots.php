<?php
    /**
	 * Copyright (C) 2003 Eric Bodden - www.bodden.de
	 * This program is free software; you can redistribute it and/or
	 * modify it under the terms of the GNU General Public License
	 * as published by the Free Software Foundation; either version 2
	 * of the License, or (at your option) any later version.
	 * This program is distributed in the hope that it will be useful,
	 * but WITHOUT ANY WARRANTY; without even the implied warranty of
	 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	 * GNU General Public License for more details.
	 * You should have received a copy of the GNU General Public License
	 * along with this program; if not, write to the Free Software
	 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
	 *
	 * Thanks to Thomas Keitel <Thomas-Keitel(at)gmx.de> for an update on
	 * "register globals" and more!
	 */
?>
<html>
<head>
<style type="text/css">
<!--
body { font-family: Verdana; }
-->
</style>
</head>
<body>
<H3>robots.txt generator by <a href="mailto:eric@bodden.de">Eric Bodden</a></H3>
<?php

// Setzen der notwendigen Variablen
$deletefile = ((isset($_GET['deletefile'])==true) ? $_GET['deletefile'] : 0);
$update     = ((isset($_GET['update'])==true) ? $_GET['update'] : 0);
$changedir  = ((isset($_GET['changedir'])==true) ? $_GET['changedir'] : 0);
$comment    = ((isset($_GET['comment'])==true) ? $_GET['comment'] : "");
$dir        = ((isset($_GET['dir'])==true) ? $_GET['dir'] : $_SERVER['DOCUMENT_ROOT']);
$id         = ((isset($_GET['id'])==true) ? $_GET['id'] : null);

// Minimieren des Anpassungsaufwands
$_PHPSELF = ((isset($PHP_SELF)==true) ? $PHP_SELF : $_SERVER['PHP_SELF']);


if($deletefile==1)
{
  if(@unlink("robots.txt"))
    print "<font color=green>robots.txt successfully deleted</font><br>";
  else
    print "<font color=red>could not delete robots.txt</font><br>";
}

if (!isset($dir) || (!$dir))
  $dir =".";
if (is_dir($dir))
{
  chdir($dir);
  $dir = getcwd();
}
if ($dir[strlen($dir)-1] != "/")
  $dir.="/";

if (!file_exists("index.html") && !file_exists("index.php") && !file_exists(".htaccess") && !file_exists(".htpasswd"))
  print "<font color=red><b>directory insecure: </b> add an index-file oder .htaccess to minimize intrusion risks!</font><br>";
else
{
  print "<font color=green>directory secured by: ";
  if (file_exists("index.html")) print "index.html, ";
  if (file_exists("index.php"))  print "index.php, ";
  if (file_exists(".htaccess")) print ".htaccess, ";
  if (file_exists("index.html")) print ".htpasswd, ";
  print "</font><br>";
}

if($update==1)
{
    $file = fopen ("robots.txt", "w");
    fputs($file,"# $comment\n\n");
    fputs($file,"User-agent: *\n");

    $i = 1;
    $d = GetDirArray($dir);
    while(list($key,$entry)=each($d))
    {
      if (is_dir($dir.$entry) && ($entry != ".") && ($entry != ".."))
      {
        if(!$id[$i]=="on")
          fputs($file,"Disallow: /".$entry."/\n");
        $i++;
      }
    }
    fclose($file);
    print "<font color=blue>robots.txt updated</font><br>";
}

if (!file_exists("robots.txt"))
{
    print "<font color=red>robots.txt not found</font>";
}
else
{
    $file = fopen ("robots.txt", "r");
    print "<font color=green>robots.txt found and read</font>";
    $comment = fgets ($file, 1024);
    $comment = substr($comment, 2);
    //overread 2 lines
    $dummy = fgets ($file, 1024);
    $dummy = fgets ($file, 1024);
    while (!feof ($file))
    {
        $line = fgets ($file, 1024);
        $line = substr($line, 11, strlen($line) - 13);
        $disallowed[$line] = true;
    }
    fclose($file);
}

print "<form action=\"".$_PHPSELF."\" method=\"get\">";
print "<input type=\"hidden\" value=\"1\" name=\"changedir\">";
print "<input type=\"text\" size=\"70\" name=\"dir\" value=\"".$dir."\">";
print "<input type=\"submit\" value=\"change dir\">";
print "</form>";
print "<form action=".$_PHPSELF." method=\"get\">";
print "<input type=hidden name=dir value='$dir'>";

echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"".$_PHPSELF."?changedir=1&dir=/\">/</a><br>\n";
$d = GetDirArray($dir);
$i = 0;

if(count($d)>0) {
	while(list($key,$entry)=each($d))
	{
	  if (is_dir($dir.$entry) && ($entry != "."))
	  {
	    if($i)
	    {
	      if(@$disallowed[$entry])
	        echo "<input type='checkbox' name='id[$i]'>&nbsp;<a href=\"".$_PHPSELF."?changedir=1&dir=$dir$entry\">".$entry."</a><br>\n";
	      else
	        echo "<input type='checkbox' name='id[$i]' checked=true>&nbsp;<a href=\"".$_PHPSELF."?changedir=1&dir=$dir$entry\">".$entry."</a><br>\n";
	    }
	    else
	      echo "&nbsp;&nbsp;&nbsp;&nbsp;<a href=\"".$_PHPSELF."?changedir=1&dir=$dir$entry\">".$entry."</a><br>\n";
	    $i++;
	  }
	}
}
else {
	print "<br><font color=red>Unable to read folder '".stripslashes($dir)."'</font><br>";
}
print "<br>comment:<br><input type=text size=70 name=comment value=".$comment."><br>";
print "<br><input type=submit value='update robots.txt' style=\"color:green\">";
print "<input type='hidden' value=1 name=update>";
print "</form>";

print "<form action=\"".$_PHPSELF."\" method=\"get\">";
print "<input type=\"hidden\" value=\"1\" name=\"deletefile\">";
print "<input type=\"submit\" value=\"delete robots.txt\" style=\"color:red\">";
print "</form>";
print "<br>USAGE: Check items for being <b>allowed</b>, uncheck items for being <b>disallowed</b> for user-agent *";

function GetDirArray($sPath)
{
	$retVal = null;
	//Load Directory Into Array
	$handle=@opendir($sPath);

	if($handle==true) {
		while ($file = readdir($handle))
		$retVal[count($retVal)] = $file;
		//Clean up and sort
		closedir($handle);
		natcasesort($retVal);
	}

	return $retVal;
}
?>
</body>
</html>
