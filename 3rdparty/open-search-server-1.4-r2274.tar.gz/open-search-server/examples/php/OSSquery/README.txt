PHP example for OpenSearchServer

Copyright Emmanuel Keller / Jaeksoft
This programm is licensed under the GPL v3.

OpenSearchServer is a search engine build in JAVA,
based on best JAVA technologies:

    * The lucene Text search engine library Apache Lucene
    * Stable and powerful server Apache Tomcat
    * An ergonomic user interface powered ZK direct RIA
 
Web site:
http://www.open-search-server.com

TO USE THIS APPLICATION :
you will need to have external libraries :
- Curl extension for php 
- SimpleXML extension for php
  