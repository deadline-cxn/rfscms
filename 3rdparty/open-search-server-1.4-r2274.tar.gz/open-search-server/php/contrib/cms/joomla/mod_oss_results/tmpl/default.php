<?php
// no direct access
defined('_JEXEC') or die('Restricted access');
include 'OSS_list.php';
include 'OSS_paging.php';
?>

<br/><br/><br/><br/>
<div class="info" ><?php echo $params->get('endMessage') ?></div>
