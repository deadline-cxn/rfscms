License:
You may use msDropDown under the terms of either the MIT License or 
the Gnu General Public License (GPL) Version 2.

The MIT License is recommended for most projects. 
It is simple and easy to understand, and it places almost no restrictions on what you can do with msDropDown.

If the GPL suits your project better, you are also free to use msDropDown under that license.

You don't have to do anything special to choose one license or the other, and you don't have to notify anyone which license you are using. 
